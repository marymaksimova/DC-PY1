src = not False and True or False and not True
result = True and True or False and False
result = True or False
result = True

print(src == result)



